<?php $__env->startSection('title', 'Admin Catagory List Page'); ?>
<?php $__env->startSection('content'); ?>

    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <div class="table-data__tool d-flex align-items-center">
                        <div class="table-data__tool-left">
                            <div class="overview-wrap">
                                <h2 class="title-1">Products List</h2>
                            </div>
                        </div>
                        <form action="<?php echo e(route('product#listPage')); ?>" method="get" class="ms-5">
                            <?php echo csrf_field(); ?>
                            <div class="d-flex">
                                <input class="form-control" value="<?php echo e(request('key')); ?>" placeholder="Search ..."
                                    name="key">
                                <button type="submit" style="background-color: rgb(148, 254, 99)" class="btn text-black"><i
                                        class="fa-solid fa-magnifying-glass"></i></button>
                            </div>
                        </form>
                        <div class="table-data__tool-right">
                            <a href="<?php echo e(route('product#createPage')); ?>">
                                <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                    <i class="zmdi zmdi-plus"></i>add new product
                                </button>
                            </a>
                            <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                CSV download
                            </button>
                        </div>
                    </div>

                    <?php if(count($pizzas) != 0): ?>
                        
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2 text-center">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>Waiting Time</th>
                                        <th>View</th>
                                        <th>Category</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="tr-shadow">
                                            <td class="col-2">
                                                <img style="height:100px;" src="<?php echo e(asset('storage/' . $pizza->image)); ?>">
                                            </td>
                                            <td><?php echo e($pizza->name); ?></td>
                                            <td><?php echo e($pizza->price); ?> Kyats</td>
                                            <td><?php echo e($pizza->waiting_time); ?> minutes</td>
                                            <td><?php echo e($pizza->view_count); ?></td>
                                            <td><?php echo e($pizza->catagory_name); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('product#view', $pizza->id)); ?>">
                                                    <button class="item mx-2" style="font-size: 20px" data-toggle="tooltip"
                                                        data-placement="top" title="View">
                                                        <i class="fa-solid fa-eye text-info"></i>
                                                    </button>
                                                </a>
                                                <a href="<?php echo e(route('product#updatePage', $pizza->id)); ?>">
                                                    <button class="item mx-2" style="font-size: 20px" data-toggle="tooltip"
                                                        data-placement="top" title="Edit">
                                                        <i class="fa-solid fa-square-pen text-success"></i>
                                                    </button>
                                                </a>
                                                <a href="<?php echo e(route('product#delete', $pizza->id)); ?>">
                                                    <button class="item mx-2" style="font-size: 20px" data-toggle="tooltip"
                                                        data-placement="top" title="Edit">
                                                        <i class="fa-solid fa-trash-can text-danger"></i>
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                        <tr class="spacer"></tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-3">
                            <?php echo e($pizzas->links()); ?>

                        </div>
                    <?php else: ?>
                        <h3 class="text-muted text-center p-5">There is no data here.</h3>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
    <!-- END PAGE CONTAINER-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\My Project\pizza_order_system\resources\views/admin/product/productList.blade.php ENDPATH**/ ?>