<?php $__env->startSection('content'); ?>
    

    <div class="w-100">
        <div class="section__content section__content--p30">
            <div class="container-fluid">

                <div class="row">
                    <div class="mt-3 mb-5 col-4  offset-1">
                        <div class="card shadow">
                            <div class="card-body">
                                <div class="card-title">
                                    <h3 class="text-center title-2">Contact Page</h3>
                                </div>
                                <hr>
                                <?php if(session('success')): ?>
                                    <div class="mb-3 px-3 pt-2">
                                        <div class="alert alert-success" role="alert">
                                            <i class="fa-solid fa-thumbs-up"></i> <?php echo e(session('success')); ?>

                                        </div>
                                    </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('user#contact')); ?>" method="post" class="p-2">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-6">
                                            <label class="form-label">Name</label>
                                            <input name="name" value="<?php echo e(old('name')); ?>"
                                                placeholder="Enter your name ..."
                                                class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="d-inline invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-6">
                                            <label class="form-label">Name</label>
                                            <input name="email" value="<?php echo e(old('email')); ?>"
                                                placeholder="Enter your email ..."
                                                class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="d-inline invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="mb-3 mt-2">
                                        <label class="form-label">Name</label>
                                        <textarea rows="6" type="text" name="message" value="<?php echo e(old('message')); ?>" placeholder="Enter your message ..."
                                            class="<?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> w-100 form-control"></textarea>
                                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="d-inline invalid-feedback">
                                                <?php echo e($message); ?>

                                            </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <button type="submit" class="btn btn-dark mb-2 p-3">Send Message</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="mt-3 mb-5 pb-3 col-4 offset-2" style="background-color: black; height:100%">
                        <div class="card shadow" style="background-color: black">
                            <div class="card-body">
                                <div class="card-title">
                                    <h3 class="text-center text-white title-2">Contact Page</h3>
                                </div>
                                <hr>
                                <div id="parent" class="mt-4">
                                    <div class="container1 mb-4">

                                        <img class="" src="<?php echo e(asset('storage/' . Auth::user()->image)); ?>"
                                            alt="Avatar" style="width:100%;">
                                        <h6 style="color: rgb(0, 255, 242)"><i
                                                class="fa-solid fa-user mr-2"></i><?php echo e(Auth::user()->name); ?></h6>

                                        <?php if($reply): ?>
                                            <p class="text-white"><?php echo e($reply->message); ?></p>
                                            <span class="time-right">11:00</span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="container1 darker">
                                        <img src="https://i.pinimg.com/736x/74/f7/5f/74f75f9e9312aad67b6cb9b2d7cdf00b.jpg"
                                            alt="Avatar" class="left " style="width:100%;">
                                        <h6 class="" style="color: rgb(0, 255, 242)"><i
                                                class="fa-solid fa-users mr-2"></i>Admin Team</h6>

                                        <?php if($reply): ?>
                                            <?php if($reply->admin_reply == null): ?>
                                                <p class="text-warning"><i class="fa-solid fa-clock mr-2 text-warning"></i>
                                                    Please wait patiently ... our team
                                                    will leave a reply within a few minutes ...</p>
                                            <?php else: ?>
                                                <p class="text-success"><i
                                                        class="fa-solid fa-circle-check mr-2 text-success"></i> Please wait
                                                    patiently ... our
                                                    team will leave a reply within a few minutes ...</p>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <span class="time-left">11:01</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\My Project\pizza_order_system\resources\views/user/contact/contact.blade.php ENDPATH**/ ?>