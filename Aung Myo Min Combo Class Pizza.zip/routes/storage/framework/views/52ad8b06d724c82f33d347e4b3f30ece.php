<?php $__env->startSection('title', 'Admin List Page'); ?>
<?php $__env->startSection('content'); ?>

    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">

                    <?php if(session('delete')): ?>
                        <div class="alert alert-danger alert-dismissible fade show w-50" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                                <i class="fa-solid fa-square-xmark"></i> <?php echo e(session('delete')); ?>

                            </button>
                        </div>
                    <?php endif; ?>

                    <div class="col-3 offset-9">
                        <form action="<?php echo e(route('admin#listPage')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <div class="d-flex">
                                <input type="text" name="key" class="form-control" value="<?php echo e(request('key')); ?>">
                                <button type="submit" class="btn btn-success text-white" placeholder="Search ..."><i
                                        class="fa-solid fa-magnifying-glass"></i></button>
                            </div>
                        </form>
                    </div>


                    <?php if(count($admins)!=0): ?>
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2 text-center">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Gender</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="tr-shadow">
                                            <td class="col-2">
                                                <?php if($admin->image == null): ?>
                                                    <img style="height:100%;" src="<?php echo e(asset('image/admin.jpg')); ?>">
                                                <?php else: ?>
                                                    <img style="height:100%;" src="<?php echo e(asset('storage/' . $admin->image)); ?>">
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($admin->name); ?></td>
                                            <td><?php echo e($admin->email); ?></td>
                                            <td><?php echo e($admin->gender); ?></td>
                                            <td><?php echo e($admin->phone); ?></td>
                                            <td><?php echo e($admin->address); ?></td>
                                            <td>
                                                <div class="table-data-feature">
                                                    <?php if(Auth::user()->id == $admin->id): ?>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('admin#changeRolePage', $admin->id)); ?>">
                                                            <button class="item mx-2" data-toggle="tooltip"
                                                                data-placement="top" title="Change Role">
                                                                <i class="fa-solid fa-pen-to-square text-info"></i>
                                                            </button>
                                                        </a>
                                                        <a href="<?php echo e(route('admin#delete', $admin->id)); ?>">
                                                            <button class="item mx-2" data-toggle="tooltip"
                                                                data-placement="top" title="Delete">
                                                                <i class="fa-solid fa-trash-can text-danger"></i>
                                                            </button>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr class="spacer"></tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-3">
                            <?php echo e($admins->appends(request()->query())->links()); ?>

                        </div>
                    <?php else: ?>
                        <h3 class="text-muted text-center p-5">There is no data here.</h3>
                    <?php endif; ?>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
    <!-- END PAGE CONTAINER-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\My Project\pizza_order_system\resources\views/admin/profile/admins.blade.php ENDPATH**/ ?>