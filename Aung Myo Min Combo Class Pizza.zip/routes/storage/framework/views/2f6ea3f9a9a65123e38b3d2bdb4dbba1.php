<?php $__env->startSection('title','Admin Catagory List Page'); ?>
<?php $__env->startSection('content'); ?>

    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <div class="table-data__tool">
                        <div class="table-data__tool-left">
                            <div class="overview-wrap">
                                <h2 class="title-1">Category List</h2>

                            </div>
                        </div>
                        <div class="table-data__tool-right">
                            <a href="<?php echo e(route('catagory#createPage')); ?>">
                                <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                    <i class="zmdi zmdi-plus"></i>add item
                                </button>
                            </a>
                            <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                CSV download
                            </button>
                        </div>
                    </div>

                    <?php if(session('deleteSuccess')): ?>
                        <div class="alert alert-danger alert-dismissible fade show w-50" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                                <i class="fa-solid fa-square-xmark"></i>       <?php echo e(session('deleteSuccess')); ?>

                            </button>
                        </div>
                    <?php endif; ?>

                    <div class="col-3 offset-9">
                        <form action="<?php echo e(route('catagory#list')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <div class="d-flex">
                                <input type="text" name="key" class="form-control" value="<?php echo e(request('key')); ?>">
                                <button type="submit" class="btn btn-success text-white" placeholder="Search ..."><i class="fa-solid fa-magnifying-glass"></i></button>
                            </div>
                        </form>
                    </div>

                    <?php if(count($catagories) != 0): ?>
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>name</th>
                                        <th>date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="tr-shadow">
                                            <td><?php echo e($catagory->id); ?></td>
                                            <td class="col-4"><?php echo e($catagory->name); ?></td>
                                            <td><?php echo e($catagory->created_at); ?></td>
                                            <td>
                                                <div class="table-data-feature">

                                                    <a href="<?php echo e(route('catagory#updatePage',$catagory->id)); ?>">
                                                        <button class="item mx-2" data-toggle="tooltip" data-placement="top" title="Edit">
                                                            <i class="fa-solid fa-pen-to-square"></i>
                                                        </button>
                                                    </a>

                                                    <a href="<?php echo e(route('catagory#delete',$catagory->id)); ?>">
                                                        <button class="item mx-2" data-toggle="tooltip" data-placement="top" title="Delete">
                                                            <i class="fa-solid fa-trash"></i>
                                                        </button>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr class="spacer"></tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-3">
                            <?php echo e($catagories->appends(request()->query())->links()); ?>

                        </div>
                    <?php else: ?>
                        <h3 class="text-muted text-center p-5">There is no data here.</h3>
                    <?php endif; ?>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
    <!-- END PAGE CONTAINER-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\My Project\pizza_order_system\resources\views/admin/catagory/list.blade.php ENDPATH**/ ?>