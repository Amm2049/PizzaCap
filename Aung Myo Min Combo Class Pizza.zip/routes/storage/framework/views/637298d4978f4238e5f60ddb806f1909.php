<?php $__env->startSection('title', 'Admin List Page'); ?>
<?php $__env->startSection('content'); ?>

    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">

                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2 text-center">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Gender</th>
                                    <th>Phone</th>
                                    <th>Address</th>
                                    <th>Role</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <input type="hidden" id="userId" value="<?php echo e($user->id); ?>">
                                        <td class="col-2">
                                            <?php if($user->image == null): ?>
                                                <img style="height:100%;" src="<?php echo e(asset('image/admin.jpg')); ?>">
                                            <?php else: ?>
                                                <img style="height:100%;" src="<?php echo e(asset('storage/' . $user->image)); ?>">
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->gender); ?></td>
                                        <td><?php echo e($user->phone); ?></td>
                                        <td><?php echo e($user->address); ?></td>
                                        <td>
                                            <select class="form-control changeRole">
                                                <option value="admin" <?php if($user->role == 'admin'): ?> selected <?php endif; ?>>
                                                    Admin</option>
                                                <option value="user" <?php if($user->role == 'user'): ?> selected <?php endif; ?>>
                                                    User</option>
                                            </select>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('user#editPage',$user->id)); ?>" >
                                                <button class="item mx-2" data-toggle="tooltip"
                                                    data-placement="top" title="Edit">
                                                    <i class="fa-solid fa-pen-to-square text-info"></i>
                                                </button>
                                            </a>
                                                <button class="item mx-2 deleteBtn" data-toggle="tooltip"
                                                    data-placement="top">
                                                    <i class="fa-solid fa-trash-can text-danger"></i>
                                                </button>
                                        </td>
                                    </tr>
                                    <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-3">
                        <?php echo e($users->links()); ?>

                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
    <!-- END PAGE CONTAINER-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptSection'); ?>

    <script>
        $(document).ready(function() {
            $('.changeRole').change(function() {
                $parentNode = $(this).parents('tr');
                $userId = $parentNode.find('#userId').val();

                $currentStatus = $parentNode.find('.changeRole').val();

                $.ajax({
                    type: 'get',
                    url: 'http://127.0.0.1:8001/user/changeRole',
                    data: {
                        'userId': $userId,
                        'role': $currentStatus
                    },
                    dataType: 'json'
                })
                location.reload();
            })

            $('.deleteBtn').click(function(){
                $parentNode = $(this).parents('tr');
                $parentNode.remove();

                $userId = $parentNode.find('#userId').val();

                $.ajax({
                    type: 'get',
                    url: 'http://127.0.0.1:8001/user/delete',
                    data: {
                        'userId': $userId,
                    },
                    dataType: 'json'
                })
            })
        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\My Project\pizza_order_system\resources\views/admin/user/control.blade.php ENDPATH**/ ?>