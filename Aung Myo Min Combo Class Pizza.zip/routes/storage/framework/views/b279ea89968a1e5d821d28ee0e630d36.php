<?php $__env->startSection('title', 'Users List Page'); ?>
<?php $__env->startSection('content'); ?>

    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">

                    <?php if(count($contacts) != 0): ?>
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2 text-center">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Date</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="tr-shadow">
                                            <input type="hidden" id="userId" value="<?php echo e($contact->id); ?>">
                                            <td><?php echo e($contact->name); ?></td>
                                            <td><?php echo e($contact->email); ?></td>
                                            <td><?php echo e($contact->created_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('user#viewReport',$contact->id)); ?>">
                                                    <button class="item mx-2" style="font-size: 20px" data-toggle="tooltip"
                                                        data-placement="top" title="View">
                                                        <i class="fa-solid fa-eye text-info"></i>
                                                    </button>
                                                </a>

                                                <button class="item mx-2 deleteBtn" style="font-size: 20px"
                                                    data-toggle="tooltip" data-placement="top" >
                                                    <i class="fa-solid fa-trash-can text-danger"></i>
                                                </button>

                                            </td>
                                        </tr>
                                        <tr class="spacer"></tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-3">
                            <?php echo e($contacts->links()); ?>

                        </div>
                    <?php else: ?>
                        <h3 class="text-muted text-center p-5">There is no data here.</h3>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
    <!-- END PAGE CONTAINER-->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\My Project\pizza_order_system\resources\views/admin/user/contact.blade.php ENDPATH**/ ?>