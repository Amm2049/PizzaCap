<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User Home Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
</head>
<body>
    <h1>User Home Page</h1>
    <h2>Role - <?php echo e(Auth::user()->role); ?></h2>
    <form action="<?php echo e(route('logout')); ?>" method="post">
        <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">Logout</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\MSI\OneDrive\Desktop\My Project\pizza_order_system\resources\views/user/home.blade.php ENDPATH**/ ?>