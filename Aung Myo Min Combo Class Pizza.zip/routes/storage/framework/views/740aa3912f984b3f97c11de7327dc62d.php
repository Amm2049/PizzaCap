<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('user#homePage')); ?>">
        <button class="mb-3 ml-4 btn btn-sm text-white px-3 py-2 rounded" style="background-color: black">Back to
            previous page</button>
    </a>
    <!-- Cart Start -->
    <div class="container-fluid">
        <div class="row px-xl-5">
            <div class="col-lg-8 offset-2 table-responsive mb-5">
                <table class="table table-light table-borderless table-hover text-center mb-0" id="dataTable">
                    <thead class="text-white" style="background-color: black">
                        <tr>
                            <th>Date</th>
                            <th>Order Id</th>
                            <th>Total Price</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody class="align-middle">
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle">
                                <td><?php echo e($order->created_at->format('j-F-Y')); ?></td>
                                <td><?php echo e($order->order_code); ?></td>
                                <td><?php echo e($order->total_price); ?></td>
                                <td>
                                    <?php if( $order->status == 0): ?>
                                        <i class="fa-solid fa-clock-rotate-left text-info"></i><span class="text-info ml-2">Pending ...</span>
                                    <?php elseif( $order->status == 1): ?>
                                        <i class="fa-solid fa-circle-check text-success"></i><span class="text-success ml-2">Success ...</span>
                                    <?php elseif( $order->status == 2): ?>
                                        <i class="fa-solid fa-rectangle-xmark text-danger"></i><span class="text-danger ml-2">Reject ...</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Cart End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\My Project\pizza_order_system\resources\views/user/order/orderPage.blade.php ENDPATH**/ ?>